package org.wdl.hotelSysTest.sys.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wdl.hotelSysTest.sys.service.OrderService;
import org.wdl.hotelSysTest.sys.service.OrderServiceImpl;
import org.wdl.hotelTest.bean.Order;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/sys/order.action")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		String id = request.getParameter("id");
		String disabled = request.getParameter("disabled");
		System.out.println("method:"+method+"   id:"+id+"  disabled:"+disabled);
		
		OrderService  orderService = new OrderServiceImpl();
		if(method != null && method.equals("list")) {
			//查询所有的订单，在前端展示
			List<Order>  orders= orderService.find();
			System.out.println("查询所有订单："+orders);
			
			request.setAttribute("orders", orders);
			request.getRequestDispatcher("/WEB-INF/jsp/sys/orderList.jsp").forward(request, response);
		}else if(method != null && method.equals("update")) {
			//删除或激活
			Order  order = orderService.findById(Integer.parseInt(id));
			System.out.println("修改前："+order);
			
			order.setDisabled(Integer.parseInt(disabled));
			System.out.println("修改后："+order);
			
			orderService.update(order);
			
			request.getRequestDispatcher("/sys/order.action?method=list").forward(request, response);
		}
		
	}

}
