package org.wdl.hotelSysTest.sys.dao;

import java.util.List;

import org.wdl.hotelTest.bean.Order;


public interface OrderDao {

	List<Order> find();

	Order findById(int id);

	void update(Order order);

}
