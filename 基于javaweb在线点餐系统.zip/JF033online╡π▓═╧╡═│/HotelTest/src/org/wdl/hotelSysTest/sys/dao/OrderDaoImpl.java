package org.wdl.hotelSysTest.sys.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.wdl.hotelTest.bean.DinnerTable;
import org.wdl.hotelTest.bean.Order;
import org.wdl.hotelTest.util.ConnectionFactory;

public class OrderDaoImpl implements OrderDao {

	@Override
	public List<Order> find() {
		//① 获取连接
		Connection connection = ConnectionFactory.getConnection();
		PreparedStatement  preparedStatement = null;
		ResultSet  resultSet= null;
		
		
		//② 准备SQL语句  
		StringBuffer  sql = new StringBuffer();
		sql.append("SELECT  * FROM tb_order torder  LEFT JOIN tb_dinner_table dtable ON torder.`table_id`=dtable.`id`");
		
		try {
			//③ 获取集装箱
			 preparedStatement = connection.prepareStatement(sql.toString());
			
			//④ 执行SQL语句
			resultSet = preparedStatement.executeQuery();
			
			
			//⑤获取查询的结果
			List<Order>  orders = new ArrayList<>();
			//因为查询出来的结果包含表头信息，所以指针下移一行，查看下一行是否有数据
			//如有数据，就进入循环体，封装该行数据到实体bean中
			while (resultSet.next()) {
				Order order = new Order();
				order.setId(resultSet.getInt("id"));
				order.setDisabled(resultSet.getInt("disabled"));
				order.setOrderCode(resultSet.getString("order_code"));
				order.setOrderDate(resultSet.getTimestamp("order_Date"));
				order.setOrderStatus(resultSet.getInt("order_Status"));
				order.setPayDate(resultSet.getTimestamp("pay_date"));
				order.setTableId(resultSet.getInt("table_id"));
				order.setTotalPrice(resultSet.getDouble("total_Price"));
				
				DinnerTable  dinnerTable = new DinnerTable();
				dinnerTable.setTableName(resultSet.getString("table_name"));
				order.setDinnerTable(dinnerTable);
				
				orders.add(order);
			}
			return orders;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
				ConnectionFactory.close(connection, preparedStatement, resultSet);
		}
		
		return null;
	}

	@Override
	public Order findById(int id) {
		//① 获取连接
		Connection connection = ConnectionFactory.getConnection();
		PreparedStatement  preparedStatement = null;
		ResultSet  resultSet= null;
		
		//② 准备SQL语句  
		StringBuffer  sql = new StringBuffer();
		sql.append("SELECT  * FROM tb_order torder  LEFT JOIN tb_dinner_table dtable ON torder.`table_id`=dtable.`id`  where torder.id = ?");
		
		try {
			//③ 获取集装箱
			 preparedStatement = connection.prepareStatement(sql.toString());
			 preparedStatement.setInt(1, id);
			
			//④ 执行SQL语句
			resultSet = preparedStatement.executeQuery();
			
			//⑤获取查询的结果
			//因为查询出来的结果包含表头信息，所以指针下移一行，查看下一行是否有数据
			//如有数据，就进入循环体，封装该行数据到实体bean中
			while (resultSet.next()) {
				Order order = new Order();
				order.setId(resultSet.getInt("id"));
				order.setDisabled(resultSet.getInt("disabled"));
				order.setOrderCode(resultSet.getString("order_code"));
				order.setOrderDate(resultSet.getTimestamp("order_Date"));
				order.setOrderStatus(resultSet.getInt("order_Status"));
				order.setPayDate(resultSet.getTimestamp("pay_date"));
				order.setTableId(resultSet.getInt("table_id"));
				order.setTotalPrice(resultSet.getDouble("total_Price"));
				
				DinnerTable  dinnerTable = new DinnerTable();
				dinnerTable.setTableName(resultSet.getString("table_name"));
				order.setDinnerTable(dinnerTable);
				return order;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				ConnectionFactory.close(connection, preparedStatement, resultSet);
		}
		return null;
	}

	@Override
	public void update(Order order) {
		//① 获取连接
		Connection connection = ConnectionFactory.getConnection();
		PreparedStatement  preparedStatement = null;
		
		//② 准备SQL语句  
		StringBuffer  sql = new StringBuffer();
		sql.append("UPDATE tb_order SET order_code=?,table_id=?,total_Price=?,"
				+ "order_Status=?,"
				+ "order_Date=?,pay_date=?,disabled=?  WHERE id =?");
		
		Date payDate = order.getPayDate() != null ? new Date(order.getPayDate().getTime()) : null;
		try {
			//③ 获取集装箱
			 preparedStatement = connection.prepareStatement(sql.toString());
			 preparedStatement.setString(1, order.getOrderCode());
			 preparedStatement.setInt(2, order.getTableId());
			 preparedStatement.setDouble(3, order.getTotalPrice());
			 preparedStatement.setInt(4, order.getOrderStatus());
			 preparedStatement.setDate(5, new Date(order.getOrderDate().getTime()));
			 preparedStatement.setDate(6, payDate);
			 preparedStatement.setInt(7, order.getDisabled());
			 preparedStatement.setInt(8, order.getId());
			
			//④ 执行SQL语句
			int resultSet = preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				ConnectionFactory.close(connection, preparedStatement, null);
		}
	}

}
