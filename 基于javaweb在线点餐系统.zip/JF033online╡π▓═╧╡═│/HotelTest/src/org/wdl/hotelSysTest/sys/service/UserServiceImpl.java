package org.wdl.hotelSysTest.sys.service;

import org.wdl.hotelSysTest.sys.dao.UserDao;
import org.wdl.hotelSysTest.sys.dao.UserDaoImpl;
import org.wdl.hotelTest.bean.User;

public class UserServiceImpl implements UserService{
	private UserDao userDao = new UserDaoImpl();
	@Override
	public User findByLoginNameAndPass(String loginname, String password) {
		return userDao.findByLoginNameAndPass(loginname,password);
	}
	@Override
	public void save(User user) {
		userDao.save(user);
	}

}
