package org.wdl.hotelSysTest.sys.service;

import java.util.List;

import org.wdl.hotelSysTest.sys.dao.OrderDao;
import org.wdl.hotelSysTest.sys.dao.OrderDaoImpl;
import org.wdl.hotelTest.bean.Order;

public class OrderServiceImpl implements OrderService {

	private OrderDao orderDao = new OrderDaoImpl();
	@Override
	public List<Order> find() {
		return orderDao.find();
	}
	@Override
	public Order findById(int id) {
		return orderDao.findById(id);
	}
	@Override
	public void update(Order order) {
		orderDao.update(order);
	}

}
