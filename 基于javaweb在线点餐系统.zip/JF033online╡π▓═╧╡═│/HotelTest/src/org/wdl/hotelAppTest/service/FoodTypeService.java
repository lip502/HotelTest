package org.wdl.hotelAppTest.service;

import java.util.List;

import org.wdl.hotelTest.bean.FoodType;

public interface FoodTypeService {

	List<FoodType> findAll();

}
